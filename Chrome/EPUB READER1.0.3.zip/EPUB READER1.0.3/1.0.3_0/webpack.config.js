const path = require('path');

module.exports = {
    mode: 'production',
    entry: {
        main: './js/reader.js'
    },
    watch: true,
    output: {
        publicPath: '/',
        filename: 'reader.js',
        path: path.resolve(__dirname, 'dist')
    },
    module: {
        rules: [
            {
                test: /\.js$/,
                exclude: /node_modules/,
                loader: 'babel-loader'
            }
        ]
    },
    performance: {
        hints: process.env.NODE_ENV === 'production' ? "warning" : false
    },
}