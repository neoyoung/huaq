import $ from 'jquery';
import Epub from 'epubjs';

; (function ($, doc) {
    const Reader = function () {
        this.eventsMap = {
            'click #open-new-book': 'openNewBook',
            'change #open-epub': 'openChangeBook',
            'click .prev-btn': 'changePrev',
            'click .next-btn': 'changeNext',
            'click .iconmulu': 'handleToggle',
            'click .slide-contents-item-label': 'handleClickToc',
            'click .iconcc-close-square': 'closeBook',
            'click .iconshezhi': 'handleSetting',
            'click .size-btn': 'handleChangeSize',
            'click .bg-btn': 'handleChangeBg'
        };

        this.selectors = {
            epubContents: '.epub-contents',
            readerWrapper: '.reader-wrapper',
            openEpubButton: '#open-epub',
            readerContainer: '.epub-reader-container',
            readerWrapperContainer: '.reader-wrapper-container',
            settingWrapper: '.setting-wrapper',
            epubContainer: '.epub-container'
        };

        this.section = 0;
        this.defaultFontSize = 20;
        this.defaultTheme = 0;
        this.currentHref = null;
        this.themeList = [
            {
                name: 'white',
                style: {
                    body: {
                        'color': '#000', 'background': '#fff'
                    }
                }
            },
            {
                name: 'sepia',
                style: {
                    body: {
                        'color': '#704214', 'background': '#f4eacd'
                    }
                }
            },
            {
                name: 'night',
                style: {
                    body: {
                        'color': '#bdcadb', 'background': '#1b1f2a'
                    }
                }
            }
        ];
        this.init();
        this.keyboard();
    };

    Reader.prototype = {
        constructor: Reader,
        init: function () {
            this.bindEvent(this.eventsMap);
            this.initializeElements();
        },
        //初始化选择器
        initializeElements: function () {
            var eles = this.selectors;
            for (var name in eles) {
                if (eles.hasOwnProperty(name)) {
                    this[name] = $(eles[name]);
                }
            }
        },
        bindEvent: function (maps) {
            this.initializeOrdinaryEvents(maps);
        },
        unbindEvent: function (maps) {
            this.uninitializeOrdinaryEvents(maps);
        },
        initializeOrdinaryEvents: function (maps) {
            this._scanEventsMap(maps, true);
        },
        uninitializeOrdinaryEvents: function (maps) {
            this._scanEventsMap(maps);
        },
        _delegate: function (name, selector, func) {
            $(doc).on(name, selector, func);
        },
        _undelegate: function (name, selector, func) {
            $(doc).off(name, selector, func);
        },
        _scanEventsMap: function (maps, isOn) {
            var delegateEventSplitter = /^(\S+)\s*(.*)$/;
            var bind = isOn ? this._delegate : this._undelegate;
            for (var keys in maps) {
                if (maps.hasOwnProperty(keys)) {
                    var matchs = keys.match(delegateEventSplitter);
                    bind(matchs[1], matchs[2], this[maps[keys]].bind(this));
                }
            }
        },
        onProgressChange(progress) {
            const percentage = progress / 100;
            const location = percentage > 0 ? this.locations.cfiFromPercentage(percentage) : 0;
            this.rendition.display(location);
        },
        openNewBook: function () {
            this.openEpubButton.click();
        },
        openChangeBook: function (event) {
            const _this = this;
            let file = event.target.files[0];
            if (file) {
                this.readerContainer.show();
                let reader = new FileReader();
                reader.onload = function () {
                    let text = this.result;

                    _this.book = new Epub(text, {});
                    _this.rendition = _this.book.renderTo("viewer", {
                        flow: "scrolled-doc",
                        width: "100%",
                        height: "100%"
                    });
                    _this.rendition.display().then(res => {
                        _this.currentHref = res.href;
                        // console.log(_this.currentHref);
                        _this.themes = _this.rendition.themes;
                        _this.setFontSize(_this.defaultFontSize + 'px');
                        _this.registerTheme();
                        _this.setTheme(_this.defaultTheme);
                    });
                    _this.book.ready.then(() => {
                        _this.navigation = _this.book.navigation;
                        _this.readerWrapperContainer.addClass('stop');
                        return _this.book.locations.generate();
                    }).then(result => {
                        // console.log(result);
                        _this.locations = _this.book.locations;
                    });
                    _this.book.loaded.navigation.then(nav => {
                        const navItem = _this.flatten(nav.toc);
                        function find(item, level = 0) {
                            return item.parent === undefined ?
                                level :
                                find(navItem.filter(parentItem => parentItem.id === item.parent)[0], ++level);
                        }
                        navItem.forEach(item => {
                            item.level = find(item);
                        });
                        _this.renderToc(navItem);
                    });
                }
                reader.readAsArrayBuffer(file);
            }
        },
        setTheme: function (index) {
            this.themes.select(this.themeList[index].name);
            this.defaultTheme = index;
        },
        registerTheme: function () {
            this.themeList.forEach(theme => {
                this.themes.register(theme.name, theme.style);
            });
        },
        closeBook: function () {
            this.readerContainer.hide();
            this.book = null;
            this.readerWrapperContainer.removeClass('stop');
            this.readerWrapperContainer.html('');
        },
        changePrev: function () {
            if (this.rendition && this.section > 0) {
                this.section = this.section - 1;
                this.displaySection();
                // this.rendition.prev().then(() => {
                //     if (this.section === 0) return;
                //     this.section--;
                //     this.refresh();
                // });
            }
        },
        changeNext: function () {
            if (this.rendition && this.section < this.book.spine.length - 1) {
                this.section = this.section + 1;
                this.displaySection();
                // this.rendition.next().then(() => {
                //     // this.section++;
                //     this.refresh();
                // });
            }
        },
        displaySection: function () {
            const sectionInfo = this.book.section(this.section);
            if (sectionInfo && sectionInfo.href) {
                this.display(sectionInfo.href, this.refresh(sectionInfo.href));
            }
        },
        keyboard: function () {
            $(document).on('keyup', (e) => {
                if (e.keyCode === 37) {
                    this.changePrev();
                } else if (e.keyCode === 39) {
                    this.changeNext();
                }
            });
        },
        setFontSize: function (fontSize) {
            if (this.themes) {
                this.themes.fontSize(fontSize);
            }
        },
        handleToggle: function () {
            if (this.epubContents.hasClass('close')) {
                this.epubContents.removeClass('close');
                this.readerWrapper.removeClass('close');
            } else {
                this.epubContents.addClass('close');
                this.readerWrapper.addClass('close');
            }

            if (this.rendition) {
                this.rendition.on("resize", function (width, height) {
                    console.log("Resized to:", width, height)
                });
            }
        },
        handleSetting: function (event) {
            if (this.settingWrapper.hasClass('show')) {
                this.settingWrapper.removeClass('show');
            } else {
                this.settingWrapper.addClass('show');
            }
        },
        handleChangeSize: function (event) {
            const tag = $(event.target).data('tag');
            if (tag === 'big') {
                this.defaultFontSize += 2;
                if (this.defaultFontSize > 30) return;
            } else if (tag === 'small') {
                this.defaultFontSize -= 2;
                if (this.defaultFontSize < 14) return
            }

            this.setFontSize(this.defaultFontSize + 'px');
        },
        handleChangeBg: function (event) {
            const type = parseInt($(event.target).data('type'), 10);

            this.setTheme(type);
            this.epubContainer.removeClass().addClass(`epub-container theme-type-${type}`);
        },
        handleClickToc: function (e) {
            let target = $(e.target);
            let href = target.attr('href');
            this.display(href, this.refresh(href));
        },
        renderToc: function (nav) {
            let navItem = '';
            nav.forEach((item, index) => {
                navItem += `
                    <div class="slide-contents-item">
                        <span class="slide-contents-item-label ${index === 0 && 'selected'}" style="margin-left: ${item.level * 25}px" title="${item.label}" href="${item.href}">${item.label}</span>
                        <span class="slide-contents-item-page"></span>
                    </div>
                `;
            });
            this.epubContents.html(navItem);
        },
        flatten: function (array) {
            return [].concat(...array.map(item => [].concat(item, ...this.flatten(item.subitems))));
        },
        display: function (target, cb) {
            if (target) {
                this.book.rendition.display(target).then(() => {
                    cb && cb();
                });
            } else {
                this.book.rendition.display().then(() => {
                    cb && cb();
                });
            }
        },
        refresh: function (href) {
            const currentLocation = this.book.rendition.currentLocation();
            if (currentLocation && currentLocation.start) {
                const startCfi = currentLocation.start.cfi;
                const progress = this.book.locations.percentageFromCfi(startCfi);
                // console.log(progress);
                this.currentHref = href;
                let item = $('.slide-contents-item');
                $.each(item, (index, ele) => {
                    $(ele).find('.slide-contents-item-label').removeClass('selected');
                    if (this.currentHref === $(ele).find('.slide-contents-item-label').attr('href')) {
                        $(ele).find('.slide-contents-item-label').addClass('selected');
                    }
                });
            }
        }
    };

    $(function () {
        new Reader();
    });
})($, document);
